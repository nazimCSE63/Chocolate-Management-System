<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>order</title>
    <style>
        h1,h2{
            color: red;
            text-align: center;
            font-size: 40px;
        }
        a{
            position: right;
        }
        p{
            text-align: justify;
            font-size: 20px;
            background: blue;
        }
    </style>
</head>
<body>
   <h1>More About Us</h1>
   <a align="center" href="../index.php">Home page</a>
   
    <p>Have you ever thought how your favorite chocolate reached you when having a bite of it, mumbling its deliciousness? It’s a perfect blend of cream, milk and cocoa, mixed at its best to serve the consumer hence leaving a person to its wanting addiction of its taste. The adaption to chocolate made many people make chocolate in a self satisfying style to eat & consume. As a part of nutrition, its verily very advantageous for blood-Pressure patients, reducing diabetes and controlling sugar level. It’s comprehended to be a very significant mood-up lifter too.Going back to 1935, a confectionery company launched a product named ‘Kit Cat’ which consisted of finger bars made of wheat and milk coated with a sophisticated layer of hot settled chocolate. The popularity of the brand grew whereas the mob really liked to intake it. This brand was later on suggested to be named ‘Kit Kat’ continuing it selling with a 4- fingers bar with different proportions of the constituents. Now, it comes in variety of wrappers, boxes with flavors such as Fruits, Dry Fruits, Dark, White and Mild embalmed in hot chocolate.</p>
    
</body>
</html>