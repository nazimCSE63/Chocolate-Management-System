<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>order</title>
    <style>
        h1,h2{
            color: red;
            text-align: center;
            font-size: 40px;
        }
        a{
            position: right;
        }
        p{
            text-align: justify;
            font-size: 20px;
            background: green;
        }
    </style>
</head>
<body>
   <h1>Product Order System</h1>
   <a align="center" href="../index.php">Home page</a>
   
   <p>Have you ever thought how your favorite chocolate reached you when having a bite of it, mumbling its deliciousness? It’s a perfect blend of cream, milk and cocoa, mixed at its best to serve the consumer 4- fingers bar with different proportions of the constituents. Now, it comes in variety of wrappers, boxes with flavors such as Fruits, Dry Fruits, Dark, White and Mild embalmed in hot chocolate.</p>
   
   <form action="/action_page.php">
  Product name:<br>
  <input type="text" name="firstname" value=""><br>
  Product Price:<br>
  <input type="text" name="lastname" value=""><br><br>
  <input type="submit" value="Submit">
</form> 
    
</body>
</html>